# Aula · Presentación v0.2

1. Leer output/pdf/PROPUESTA_PARA_ENTREGA.pdf.
2. Abrir demo/index.html en un navegador para recorrer la simulación.
3. Consultar GUIA_PARA_PRESENTAR.md para explicar el alcance.

ALCANCE_DE_LA_PROPUESTA.md es la referencia común. El mínimo propuesto funciona sin API; la asistencia externa es opcional. La conexión API directa necesita validar un proveedor. El intercambio manual no es una conexión automática.

La demo usa preguntas preparadas. No procesa material propio ni tiene IA conectada. Los modos básico y asistido son explicativos y utilizan los mismos ejemplos.

El HTML incluye sus recursos y abre sin instalación. La aplicación final aún no está implementada. El modo básico previsto no requiere pagos; un servicio externo tiene sus propias condiciones y no está incluido.

VERSION_PRESENTACION.json permite comprobar que estos archivos coinciden con los empaquetados en esta edición. El informe Markdown es editable. Incorporar nombres de los integrantes si se requiere antes de entregar.
