# Aula - Presentación del proyecto integrador

1. Abrir Aula_Informe.pdf para presentar la propuesta (dos páginas).
2. Abrir Aula_Demo.html con doble clic en un navegador. Es un único archivo y funciona sin instalación ni conexión a internet.
3. Usar el apunte incorporado, avanzar a configuración y elegir una o dos respuestas correctas (o combinar ambas).
4. Mostrar clave y fundamento, editar una pregunta, aprobar las elegidas y descargar el examen y la clave por separado.

La demo no usa IA ni genera preguntas nuevas: selecciona variantes de seis ejemplos preparados. La carga de un texto propio solo permite previsualizarlo; restaurar el apunte para simular el examen.

El sistema final previsto usará modelos preentrenados con recuperación de contenido y revisión docente. No se entrenará desde cero.

PROPUESTA_EDITABLE.md conserva el informe como texto Markdown para editar. Agregar nombres de los integrantes si corresponde.
